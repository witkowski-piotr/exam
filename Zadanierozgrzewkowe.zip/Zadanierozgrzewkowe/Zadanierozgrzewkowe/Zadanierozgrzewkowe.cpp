﻿#include <iostream>
#include <cstdlib>

using namespace std;

class Liczba {
public:
    void wczytaj() {
        cin >> m_liczba;
    }

    void wypisz() const {
        cout << m_liczba << endl;
    }

    void nadaj_w(int liczba) {
        m_liczba = liczba;
    }

    int wartosc() const {
        return m_liczba;
    }

    int wartosc_bezwzgledna() const {
        return abs(m_liczba);
    }

private:
    int m_liczba;
};
