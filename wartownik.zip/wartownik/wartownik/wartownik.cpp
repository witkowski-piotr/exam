﻿
#include <iostream>
#include <cstdlib>
#include <ctime>


using namespace std;

const int SIZE = 50;
const int MIN_VAL = 1;
const int MAX_VAL = 100;

int find(int arr[], int n, int x) {
    // dodanie wartownika
    arr[n] = x;

    int i = 0;
    while (arr[i] != x) {
        i++;
    }

    // usunięcie wartownika
    if (i == n) {
        return -1;
    }
    else {
        return i;
    }
}

void fillArray(int arr[], int size)
{
    srand(time(NULL));//generator!!!

    for (int i = 0; i < size; i++)
    {
        arr[i] = rand() % (MAX_VAL - MIN_VAL + 1) + MIN_VAL;

    }
}


void printArray(int arr[], int size) {

    for (int i = 1; i < size; i++)
    {
        cout << arr[i] << " ";
    }
    cout << endl;

}





int main()
{
    int arr[SIZE];
    fillArray(arr, SIZE);

    cout << "Tablica przed sortowaniem: " << endl;
    printArray(arr, SIZE);

    int x;
    cout << "Podaj wartosc do wyszukania: ";
    cin >> x;

    int index = find(arr, SIZE, x);

    if (index != -1)
    {
        cout << "Element " << x << " znajduje sie pod indeksem " << index << "." << endl;

    }
    else
    {
        cout << "Element nie zostal odnaleziony" << endl;
    }

    return 0;

};

